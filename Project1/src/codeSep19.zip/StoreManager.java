package edu.auburn;

public class StoreManager {

    public static void main(String[] args) {
        System.out.println("Hello class!");
        SQLiteDataAdapter adapter = new SQLiteDataAdapter();
        adapter.connect();
        ProductModel product = adapter.loadProduct(2);

        System.out.println("Product: ID = " + product.mProductID + " Name = " + product.mName);
//        System.out.println(product);

        AddProductView addProductView = new AddProductView();
        AddProductController addProductController = new AddProductController(addProductView, adapter);

        addProductView.setVisible(true);

    }
}
