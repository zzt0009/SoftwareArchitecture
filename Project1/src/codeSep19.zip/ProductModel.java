package edu.auburn;

public class ProductModel {
    public int mProductID;
    public String mName, mVendor;
    public double mPrice, mQuantity;
}
