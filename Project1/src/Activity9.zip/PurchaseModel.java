public class PurchaseModel {
    public int mPurchaseID, mCustomerID, mProductID;
    public double mCost, mTax, mTotalCost, mPrice, mQuantity;
    public String mDate;
}
