public class CustomerModel {
    public int mCustomerID;
    public String mName, mAddress, mPhone;
}
