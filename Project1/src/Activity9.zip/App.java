
public class App {
    public static void main(String[] args) {
        System.out.println("Hello class!");
        StoreManager.getInstance().run();
//        ProductModel product = adapter.loadProduct(2);

//        if (product != null)
//        System.out.println("Product = " + product);
//        else
//            System.out.println("Product not exists!");



    }
}
